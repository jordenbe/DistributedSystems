package ds.gae.workers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.google.appengine.api.taskqueue.DeferredTask;

import ds.gae.CarRentalModel;
import ds.gae.ReservationException;
import ds.gae.entities.CarRentalCompany;
import ds.gae.entities.Quote;

public class ConfirmQuoteWorker implements DeferredTask {

	private static Logger logger = Logger.getLogger(CarRentalCompany.class.getName());
	
	private ArrayList<Quote> qs = new ArrayList();

	public ConfirmQuoteWorker(Collection<Quote> qs) {
		if(qs != null)
		{
			this.qs = new ArrayList(qs);	
		}
	}

	@Override
	public void run() {
		try {
			CarRentalModel.get().confirmQuotes(qs);
		} catch (ReservationException e) {
			logger.log(Level.INFO, e.getMessage());
		}
	}

}
